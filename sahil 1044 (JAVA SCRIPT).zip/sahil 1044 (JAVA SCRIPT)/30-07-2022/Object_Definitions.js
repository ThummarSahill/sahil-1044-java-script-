
let Cars = {Company:"Mahindra Thar", Model:"X4", Color:"Red", Cost:1000000};
document.write(Cars.Company + " " + Cars.Model + " " + Cars.Color + " " + Cars.Cost);

const CarsObj = {Company:"Mahindra Thar", Model:"X3", Color:"Black", Cost:1000000};
document.write("<br/>"+CarsObj.Company + " " + CarsObj.Model + " " + CarsObj.Color + " " + CarsObj.Cost);