document.write("<br><b>Arithmetic</b><br>");
let x = 50,y = 50;
let z = x + y;
document.write(z);

let a = 3;
let b =(100+50)*a;
document.write("<br><b>Addition</b><br>",b);

let o = 50;
let p =20;
let q=o-p;
document.write("<br><b>Substracting:</b><br>",q);

let e = 50;
let f =20;
let g=e*f;
document.write("<br><b>Multiplying:</b><br>",g);

let k = 50;
let i =20;
let h=k/i;
document.write("<br><b>Dividing:</b><br>",h);

let x1 = 50;
let y1 =20;
let z1=x2%y1;
document.write("<br><b>Remainder:</b><br>",z1);

let a1 = 50;
a1++;
let b1=a1;
document.write("<br><b>Increment:</b><br>",b1);




let d1 = 50;
d2=d1**20;
document.write("<br><b>Exponentiation:</b><br>",d2);